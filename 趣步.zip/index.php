
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <title>趣刷步-刷步数,微信运动,免费在线刷步</title>
    <meta name="keywords" content="趣刷步,24小时免费刷步网,刷步数,微信怎么刷步数,刷步数接口,手环刷步数,小米运动刷步数,乐心健康刷步数,微信运动刷步数,支付宝刷步,微信刷步,改步数,运动助手WEB版,运动助手,WEB版,运动宝,运动宝接口,爱刷步,卓易健康,小米运动,乐心健康,,运动宝,运动宝盒,运动宝IOS,运动宝8.0.6,运动宝盒助手,运动助手app,运动助手官网,运动助手app网盘下载,运动助手怎么同步微信,运动宝苹果版,支付宝刷步,qq刷步,微博刷步">
    <meta name="description" content="趣刷步,24小时免费刷步网,刷步数,微信怎么刷步数,刷步数接口,手环刷步数,趣刷步,小米运动刷步数,乐心健康刷步数,微信运动刷步数,支付宝刷步,微信刷步,改步数,运动助手WEB版,运动助手,WEB版,运动宝,运动宝接口,爱刷步,卓易健康,小米运动,乐心健康,,运动宝,运动宝盒,运动宝IOS,运动宝8.0.6,运动宝盒助手,运动助手app,运动助手官网,运动助手app网盘下载,运动助手怎么同步微信,运动宝苹果版,支付宝刷步,qq刷步,微博刷步">
    <script src="//cdn.bootcss.com/jquery/3.3.1/jquery.min.js" type="text/javascript"></script>
    <script src="//cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="//cdn.bootcss.com/layer/2.3/layer.js" type="text/javascript"></script>
    <link href="https://baiquyun.top/css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="container" style="padding-top:20px;">
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
        <div class="panel panel-default card-view">
            <div class="row heading-bg bg-green text-center">
                <h5 class="txt-light">在线刷步数【免费版】</h5>
            </div>
            <div class="item">
                <div class="testimonial-wrap text-center pl-20 pr-20">
                    <p style="color:#F15B26;font-size: 16px">公告：反馈的接口问题已修复，目前均可正常使用！安卓、苹果通用<br/>2021年5月26日</p>
                    <br/>
                    <a class="btn btn-success btn-xs" target="_blank" href="https://050009.cn">小米教程</a>
                    <a class="btn btn-info btn-xs" target="_blank" href="https://050009.cn">乐心教程</a>
                </div>
            </div>
            <hr>
            <div class="tab-struct custom-tab">
                <ul role="tablist" class="nav nav-tabs" id="myTabs_15">
                    <li class="active" role="presentation">
                        <a data-toggle="tab" href="#xiaomi">小米运动</a>
                    </li>
                    <li role="presentation">
                        <a data-toggle="tab" href="#lifesese">乐心健康</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div id="xiaomi" class="tab-pane fade active in">
                        <div class="input-group">
                            <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span> 小米账号</span>
                            <input id="phone" type="text" class="form-control" placeholder="输入小米账号"/>
                        </div>
                        <br>
                        <div class="input-group">
                            <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span> 小米密码</span>
                            <input id="password" type="password" class="form-control" placeholder="输入小米密码"/>
                        </div>
                        <br>
                        <div class="input-group">
                            <span class="input-group-addon"><span class="glyphicon glyphicon-send"></span> 同步步数</span>
                            <input id="steps" type="number" class="form-control" placeholder="输入同步步数"/>
                        </div>
                        <br>
                        <blockquote>
                            小米运动不支持同步到QQ运动中。
                        </blockquote>
                        <center>
                            <button onclick="login()" class="btn btn-primary">点击提交</button>
                        </center>
                    </div>
                    <div id="lifesese" class="tab-pane fade">
                        <div class="input-group">
                            <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span> 乐心账号</span>
                            <input id="lxphone" type="text" class="form-control" placeholder="输入乐心账号"/>
                        </div>
                        <br>
                        <div class="lifesense_password">
                            <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span> 乐心密码</span>
                                <input id="lxpassword" type="password" class="form-control" placeholder="输入乐心密码"/>
                            </div>
                            <br/>
                        </div>
                        <div class="input-group">
                            <span class="input-group-addon"><span class="glyphicon glyphicon-send"></span> 同步步数</span>
                            <input id="lxsteps" type="number" class="form-control" placeholder="输入同步步数"/>
                        </div>
                        <br>
                        <blockquote>
                            需要乐心账号绑定手环后才能同步步数。
                        </blockquote>
                        <center>
                            <button onclick="lxlogin()" class="btn btn-primary" disabled="disabled">敬请期待</button>
                        </center>
                    </div>
                </div>
            </div>
        </div>
        <div class="panel panel-default card-view">
            <center><a href="https://050009.cn">小菜鸡</a></center>
        </div>
    </div>
</div>


<script src="https://baiquyun.top/static/js/mi.js" type="text/javascript"></script>
<!--<script src="https://baiquyun.top/static/js/lx.js" type="text/javascript"></script>-->
</body>
</html>